from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import json
from pymongo import MongoClient
import json


s = Service('./chromedriver.exe')
driver = webdriver.Chrome(service=s)
driver.implicitly_wait(10)

driver.get('https://account.mail.ru/login')

login = driver.find_element(By.NAME, 'username')
login.send_keys('study.ai_172@mail.ru')
login.send_keys(Keys.ENTER)

pwd = driver.find_element(By.XPATH, '//input[@name="password"]')
pwd.send_keys('Password!@#')
pwd.send_keys(Keys.ENTER)


def collect_letter_links():
    letters_links_list = []
    total_letters = driver.find_element(By.XPATH, '//span[@class="ph-notify svelte-egj08t ph-notify_current"]').text

    while len(letters_links_list) <= int(total_letters):
        letters = driver.find_elements(By.XPATH,
                                       '//div[@class="ReactVirtualized__Grid__innerScrollContainer"]//a[contains(@class, "llc")]')

        for elements in range(len(letters)):
            letter = letters[elements]
            link_to_letter = letter.get_attribute('href')
            letters_links_list.append(link_to_letter)

        actions = ActionChains(driver)
        actions.move_to_element(letters[-1])
        actions.perform()
    return letters_links_list


def letter_parser(collected_elements):
    letters_parser = []
    for link_to_letter in collected_elements:
        driver.get(link_to_letter)

        letter_sender = driver.find_element(By.CLASS_NAME, 'letter-contact').text
        letter_date_sent = driver.find_element(By.CLASS_NAME, 'letter__date').text
        letter_theme = driver.find_element(By.TAG_NAME, 'h2').text
        letter_text_list = driver.find_elements(By.XPATH, '//tr/td/div/p')
        letter_text = []

        for el in letter_text_list:
            if el.text:
                text = el.text
                letter_text.append(text)

        letter_info = {
            "letter_sender": letter_sender,
            "letter_theme": letter_theme,
            "letter_date_sent": letter_date_sent,
            "letter_text": letter_text,
        }
        letters_parser.append(letter_info)

    return letters_parser


collect_letter_links()
links_list = collect_letter_links()
letter_parser_downloaded = letter_parser(links_list)



with open('letters_parser_downloaded.json', 'w') as parsed_file:
    json.dump(letter_parser_downloaded, parsed_file)

client = MongoClient('mongodb://127.0.0.1:27017/')
db_mail_ru = client.mail_ru
db_mail_ru.mail_ru.insert_many(letter_parser_downloaded)