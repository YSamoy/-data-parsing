import scrapy
from scrapy.pipelines.images import ImagesPipeline


class CastoramaParserPipeline:
    def process_item(self, item, spider):
        return item


class CastoramaParserPipelinePhotos(ImagesPipeline):
    def get_media_requests(self, item, info):
        if item.get('photos'):
            for img in item.get('photos'):
                try:
                    yield scrapy.Request(img)
                except Exception as error:
                    print(error)

    def item_completed(self, results, item, info):

        if results:
            item['photos'] = [itm[1] for itm in results if itm[0]]
        return item
