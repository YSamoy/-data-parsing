import scrapy
from itemloaders.processors import Compose, TakeFirst

def process_photos(value):
    links = []
    if value:

        for photo_link in value:
            links.append('https://www.castorama.ru' + photo_link)
    return links


class CastoramaParserItem(scrapy.Item):

    name = scrapy.Field(output_processor=TakeFirst())
    url = scrapy.Field(output_processor=TakeFirst())
    price = scrapy.Field(output_processor=TakeFirst())
    photos = scrapy.Field(input_processor=Compose(process_photos))

    # name = scrapy.Field()
    # url = scrapy.Field()
    # price = scrapy.Field()
    # photos = scrapy.Field()


